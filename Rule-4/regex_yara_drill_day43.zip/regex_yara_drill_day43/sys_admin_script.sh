
#!/bin/bash
# legit admin script
echo "Updating shared libraries (.dll mention here is just text)"
server="update[dot]server[dot]local"
curl -s https://intranet.local/status || true
