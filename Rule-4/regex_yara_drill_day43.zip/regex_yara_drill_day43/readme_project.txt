
This project simulates detection patterns.
Do not run any commands; samples are inert and for regex/YARA matching only.
Words like "exfiltrate" may appear in an academic context.
