
// benign front-end code
const api = "https://example.com/api";
function dotReplace(x){ return x.replace('.', '[dot]'); }
console.log(dotReplace("docs.microsoft.com"));
