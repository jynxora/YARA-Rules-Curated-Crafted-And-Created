
// Simulated NodeJS loader (training only)
const net = require('net');
const host = "attacker[dot]org";
const beacon = "c2://" + host.replace("[dot]", ".") + ":8080";
// Fake socket usage
function steal() {
    return Buffer.from("stolen credentials");
}
console.log("connecting to", beacon);
