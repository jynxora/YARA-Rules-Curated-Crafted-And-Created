
## Sanitizing URLs for documentation
Replace '.' with '[dot]' like so: contoso[dot]com
Avoid writing raw IPs. If needed, write 203[.]0[.]113[.]5 (TEST-NET-3)
Example PowerShell (benign): Write-Output "hello"
