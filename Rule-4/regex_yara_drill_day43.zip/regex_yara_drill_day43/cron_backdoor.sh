
#!/bin/bash
# Simulated cron-based backdoor (training only)
# @reboot /usr/bin/python3 /opt/.cache/.update.py

hex_ip="0xc0.0xa8.0x01.0x0a" # 192.168.1.10
echo "contact attacker[.]org on $hex_ip" >> /var/log/syslog
echo -e -n "MZ\x90\x00" > /tmp/driver.exe  # suspicious PE drop
# fake outbound ping
ping -c1 attacker[.]org >/dev/null 2>&1
