
# Benign script
Write-Output "System inventory"
$s = "R2V0LVByb2Nlc3MgfCBTZWxlY3QtT2JqZWN0IE5hbWUsSWQ="
# Example of encoding used for safe demos only.
$decoded = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($s))
Write-Output $decoded
